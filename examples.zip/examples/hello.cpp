#include <iostream>

int main() {
    std::cout << "Hello C++" << std::endl;
    return 0;
}
